package com.javabykiran;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)			throws ServletException, IOException {
		Connection connection = null;
		Statement statement = null;
		boolean userExist = false;
		String username = request.getParameter("uname");
		String password = request.getParameter("pword");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "root");
			statement = connection.createStatement();
			String sql = "select * from users where username='" + username + "'";
			System.out.println(sql);
			ResultSet resultSet = statement.executeQuery(sql);
			if (resultSet.next()) {
				userExist = true;
			}
			if (userExist) {
				String sql1 = "select username from users";
				ResultSet resultSet1 = statement.executeQuery(sql1);
				ArrayList<String> alUnameList = new ArrayList<>();
				while (resultSet1.next()) {
					alUnameList.add(resultSet1.getString(1));
				}
				request.setAttribute("data", alUnameList);
				RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
				rd.forward(request, response);
			} else {
				request.setAttribute("msg", "Your userId and Password are Wrong");
				RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
				rd.forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("some issue in connection.......");
		}

	}

}
