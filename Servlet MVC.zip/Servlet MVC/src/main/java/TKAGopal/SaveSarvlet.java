package TKAGopal;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SaveSarvlet
 */
@WebServlet("/SaveSarvlet")
public class SaveSarvlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());

		String id = request.getParameter("id");
		String name = request.getParameter("name");
		System.out.println("Helllllllllo");
		System.out.println(id + " " + name);
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3737/gopal", "root", "root");
			PreparedStatement ps=c.prepareStatement("insert into student values(?,?)");
			ps.setString(1, id);
			ps.setString(2, name);
			ps.executeUpdate();
			System.out.println("Record Inserted...");
			c.close();
		} catch (Exception e) {
			System.out.println("I have Handle a this type of Exception " + e);
		}

	}

}
