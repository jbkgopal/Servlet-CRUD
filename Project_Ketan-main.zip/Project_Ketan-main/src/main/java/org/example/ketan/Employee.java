package org.example.ketan;

public class Employee {

    private int id;
    private String Username;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public int getAge() {
        return Age;
    }

    public void setAge(int age) {
        Age = age;
    }

    public long getPhone_no() {
        return Phone_no;
    }

    public void setPhone_no(long     phone_no) {
        Phone_no = phone_no;
    }

    private int Age;
    private long Phone_no;
}



