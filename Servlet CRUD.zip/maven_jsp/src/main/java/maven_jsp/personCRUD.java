package maven_jsp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class personCRUD {

	public int save(Person person) throws ClassNotFoundException, SQLException,Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");

		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/persondb", "root", "root");

		PreparedStatement preparedStatement = connection.prepareStatement("insert into person values(?,?,?,?,?)");

		preparedStatement.setInt(1, person.getId());
		preparedStatement.setString(2, person.getName());
		preparedStatement.setLong(3, person.getPhone());
		preparedStatement.setString(4, person.getEmail());
		preparedStatement.setString(5, person.getPassword());

		int result = preparedStatement.executeUpdate();
		connection.close();
		return result;

	}
	
	public String login(String email) throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.cj.jdbc.Driver");

		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/persondb", "root", "root");

		PreparedStatement preparedStatement = connection.prepareStatement("select * from person where email=?");

		preparedStatement.setString(1, email);
		
		String pass = null;

		ResultSet resultSet = preparedStatement.executeQuery();
		while (resultSet.next())
		{
			pass = resultSet.getString("password");
		}
		connection.close();
		return pass;
		
	}

}
