package maven_jsp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/login")
public class signIn extends GenericServlet{

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		
		PrintWriter printWriter = res.getWriter();
		personCRUD  crud = new personCRUD();
		try {
			String dbpassword = crud.login( email);
			
			if (dbpassword.equals(password)) {
				printWriter.print("Login success !");
			} else {
				printWriter.print("Login failed !");
			}
			
			
			
		} catch (ClassNotFoundException | SQLException  | NullPointerException e ) {
			// TODO Auto-generated catch block
			printWriter.print("Enter a valid email!");
			e.printStackTrace();
		}
		
		
		
	}

}
