package maven_jsp;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/save")
public class signUp extends GenericServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {

		int id = Integer.parseInt(req.getParameter("id"));
		String name = req.getParameter("name");
		long phone = Long.parseLong(req.getParameter("phone"));
		String email = req.getParameter("email");
		String password = req.getParameter("password");

		Person person = new Person();
		person.setId(id);
		person.setName(name);
		person.setPhone(phone);
		person.setEmail(email);
		person.setPassword(password);
		
		personCRUD crud = new personCRUD();
		PrintWriter printWriter = res.getWriter();
		try {
			
			int result =crud.save(person);
			
			if(result != 0)
			{
				printWriter.print("sign up successfull.....!!!!");
			}
			else
			{
				printWriter.print("sign up failed.....!!!!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}

}
